# Cutebot swarm project guide

Start with [cutebot_variable_grid_controller.zip](cutebot_variable_grid_controller.zip) for the latest simulator, trained weights, and camera-host controller. Extract each ZIP into its own folder. Several bundles contain files with the same name, and the latest controller uses a different observation format from v7.

This folder contains what you need to replay the saved failures, run the Python simulator, and evaluate or retrain the latest actor after installing NumPy and PyTorch. The physical setup still needs a calibrated camera tracker, a radio link, and robot firmware that executes commands and stops when updates expire.

## Files in this folder

| File | What it contains |
| --- | --- |
| [cutebot_variable_grid_controller.zip](cutebot_variable_grid_controller.zip) | Latest controller. Variable grid dimensions, movable target, camera packets with peer poses, and stalled-motion recovery. |
| [cutebot_turn_oscillation_fix.zip](cutebot_turn_oscillation_fix.zip) | Earlier 24-input v7 actor with a guard against repeated left-right turns. Includes Python and C inference. |
| [cutebot_trained_model.zip](cutebot_trained_model.zip) | Original v7 actor exports, checkpoints, training plots, and performance reports before the turn guard. |
| [cutebot_swarm_imitation_ppo_v7.ipynb](cutebot_swarm_imitation_ppo_v7.ipynb) | Colab notebook for the fixed-grid v7 model. It trains behavior cloning, DAgger, and PPO. Open it in Colab and select a GPU runtime to retrain this version. |
| [cutebot_failure_replays.html](cutebot_failure_replays.html) | Offline browser viewer for all 85 failures from the original v7 held-out comparison. Open it and select a case to play or scrub. It shows the original trajectories before the controller fixes. |

## Latest variable-grid controller

Open the extracted bundle's `README.md` for setup and the camera interface. From that folder, with NumPy and PyTorch installed, run:

```text
python check.py
python evaluate.py --fresh
python train.py
```

The first command checks arena geometry, camera packets, stale tracking behavior, and reverse recovery. The second reruns the saved benchmark configuration and writes `evaluation.json`. The third retrains the actor and writes checkpoints under `training_output/`.

| File | What it does |
| --- | --- |
| `README.md` | Setup, units, coordinate conventions, motor action IDs, and integration notes. |
| `arena.py` | Simulator, fixed physical dimensions, variable arena and goal placement, 25-feature observation encoder, policy network, and training teacher. |
| `camera_host.py` | Converts calibrated robot and object poses into observations and per-robot command packets. Each valid packet includes the other two robots' poses. Invalid or stale tracking produces stop commands. |
| `swarm_recovery.py` | Tracks alternating turns and stalled motion. It can select a nearby robot to yield or reverse when that opens a gap. |
| `variable_policy_state_dict.pt` | Trained 25-input PyTorch checkpoint used by the camera host and evaluation script. |
| `train.py` | Trains on varied layouts using behavior cloning and DAgger, then selects a checkpoint on validation. |
| `evaluate.py` and `evaluation.json` | Reproducible comparison of the same actor with and without stalled-motion recovery, with room sizes, seeds, success counts, and contact counts. |
| `check.py` | Quick checks for the simulator, camera packet contract, and recovery behavior. |

Training varied both grid axes from 4 to 8 feet with fixed robot and object dimensions. Simulation tests included a 12 x 8 ft layout. The goal diameter varies from 36 to 47 cm and can move off-center on larger layouts, subject to camera clearance. In the paired benchmark, the recovery rule reduced time near robot contact by 4.7%. Full deliveries were 1,104 of 1,120 with the turn guard alone and 1,103 of 1,120 with stalled-motion recovery added.

## Camera, controller, and Cutebot integration

The camera tracker measures the scene. The Python host turns those measurements into 25 features per robot, runs the trained model and recovery logic, and returns three addressed commands. Your radio bridge sends each command to the corresponding Cutebot. The Cutebot firmware translates the action ID into motor commands.

### Configure once per layout

Pass these fields to `CameraHost(...)` from the extracted variable-grid bundle.

| Field | Source | Format and meaning |
| --- | --- | --- |
| `grid_ft` | Arena setup | `(width, height)` in feet. Each axis must be at least 4 ft. |
| `goal_center_m` | Arena setup or calibrated goal marker | `(x, y)` in meters. A 4 × 4 ft grid uses the center. Larger layouts can use an off-center goal within the allowed clearance. |
| `goal_radius_m` | Arena setup | Radius in meters, from `0.18` to `0.235`. |
| `camera_min_m`, `camera_max_m` | Camera calibration | Lower and upper `(x, y)` bounds of the usable tracking area in meters. The bounds must cover the marked grid and leave at least 0.43 m between the goal boundary and the edge of the usable camera view. |
| `assignments` | Task setup | Three distinct object IDs in robot ID order. For `(2, 0, 1)`, robots 0, 1, and 2 push objects 2, 0, and 1 respectively. Maintain a mapping from each robot ID to its radio address. |

Use one calibrated floor coordinate system. Set `(0, 0)` at the grid corner where the positive width and height axes begin. Convert image pixels to ground-plane meters, and measure each robot's heading from the positive x-axis, counterclockwise in radians. Keep robot and object IDs stable across frames.

### Supply one complete snapshot per control update

Call `dispatch(...)` about every 0.14 seconds, using a fresh snapshot from the tracker. Supply all positions and headings from the same capture.

| Argument | Shape or unit | What to send |
| --- | --- | --- |
| `robot_xy_m` | `(3, 2)`, meters | Center position of each Cutebot in robot ID order 0, 1, 2. |
| `heading_rad` | `(3,)`, radians | Forward heading of each Cutebot in that same order. |
| `object_xy_m` | `(3, 2)`, meters | Center position of each object in object ID order 0, 1, 2. |
| `captured_at` | Seconds | Timestamp recorded at capture on the camera host's monotonic clock. It must advance with each new frame. |
| `host_now` | Seconds | Current time from the same monotonic clock when calling `dispatch()`. The host rejects snapshots older than 0.28 seconds. |

If a tracker loses a tag, report the missing pose with a non-finite value so the host sends STOP. The host also sends STOP when it receives a repeated timestamp or a pose outside the allowed tracking area. The peer positions and recent displacement used for stalled-motion recovery come from these camera snapshots.

### Route the host's commands to the robots

For each valid command, `dispatch()` returns a dictionary with `robot_id`, `sequence`, `tracking_valid`, `action`, `recovering`, `command_timeout_ms`, and `other_robots`. Each entry in `other_robots` contains the peer's `id`, `xy_m`, and `heading_rad`. Invalid-tracking packets carry the recipient ID, sequence, a STOP action, and `tracking_valid=False`. The Python dictionaries are the interface to your radio bridge. Choose a wire encoding that fits your link.

The firmware should accept only commands addressed to its own ID, reject out-of-order commands within the radio session, and stop on invalid tracking or if a fresh command fails to arrive before the timeout. The timeout on valid packets is 140 ms. Establish a new radio session after a host restart so sequence tracking can restart cleanly. Map the action IDs to calibrated motor commands.

| ID | Command |
| --- | --- |
| 0 | Stop |
| 1 | Forward |
| 2 | Rotate left |
| 3 | Rotate right |
| 4 | Forward and turn left |
| 5 | Forward and turn right |
| 6 | Reverse |

### Minimal host-side example

Run this from the extracted variable-grid folder. The coordinates are example test values. Replace them with the tracker measurements and use the actual capture timestamp when running live.

```python
from time import monotonic
from camera_host import CameraHost

host = CameraHost(
    grid_ft=(8, 6),
    goal_center_m=(0.70, 0.90),
    goal_radius_m=0.18,
    camera_min_m=(-0.65, -0.65),
    camera_max_m=(3.10, 2.50),
    assignments=(2, 0, 1),
)

captured_at = monotonic()
packets = host.dispatch(
    robot_xy_m=[(0.30, 0.40), (1.60, 0.35), (2.00, 1.30)],
    heading_rad=[0.0, 1.57, 3.14],
    object_xy_m=[(0.95, 0.45), (1.45, 0.85), (1.85, 1.20)],
    captured_at=captured_at,
    host_now=monotonic(),
)
for packet in packets:
    print(packet)  # Replace with radio send to the address for packet["robot_id"].
```

The host loads `variable_policy_state_dict.pt` and calls `encode_observation()` in `arena.py` to build the model input. The encoder derives relative robot and object positions, heading and approach bearings, and the target radius feature. Grid dimensions and camera bounds configure geometry and tracking checks. The firmware receives action IDs and peer poses through the radio bridge.

## Earlier turn-oscillation fix

The extracted bundle's `README.md` describes the guard and its per-robot state. `cutebot_policy.py` loads the v7 weights from `cutebot_actor_float32.npz`. `cutebot_policy.h` provides the corresponding 24-input C interface with turn history. `policy_metadata.json` documents the observation order and action IDs. `evaluation.json` records the before-and-after results. The Python controller solved 1,013 of 1,024 fresh simulation episodes. The C header still needs to be compiled and tested in the target firmware.

## Original v7 model and reports

The extracted bundle's `RESULTS.md` explains the benchmark, and `README_DEPLOYMENT.txt` describes the v7 inputs and deployment assumptions. Its files fall into three groups.

- **Model and inference.** `best_policy_state_dict.pt` is the selected PPO checkpoint. `imitation_policy_state_dict.pt` is the pre-PPO checkpoint. `cutebot_actor_float32.npz` holds the actor weights, `cutebot_policy.h` runs 24-input inference, and `policy_metadata.json` defines the inputs and actions.
- **Results and logs.** `comparison.json` compares v5, v7 imitation, and v7 PPO on matching layouts. `evaluation.json` and `heldout_metrics.json` record holdout results. `training_history.csv` and `ppo_diagnostics.csv` record training and PPO checkpoint metrics.
- **Plots.** `training_curves.png` shows progress across training stages. `ppo_stability.png` shows PPO diagnostics. `stage_trajectories.png` shows trajectories from the training checkpoints.

Keep the 24-input v7 weights and headers with their own bundle. For the current variable-grid setup, use the 25-input checkpoint and the matching scripts together.

## Workspace folders

`outputs/` contains the files you need to keep or share. The sibling `work/` folder contains the local Python environment, intermediate runs, scripts, and logs used to build and verify these downloads. The ZIPs contain the source, weights, and results needed to use the delivered controllers independently of `work/`.
