/**
 * microbit_comms.ts  -  communication skeleton for EACH micro:bit (MakeCode)
 *
 * This program only sends and receives text lines over Bluetooth. It contains
 * no motor or control code: put your own behaviour in handleMessage() below.
 *
 * SETUP IN MAKECODE (https://makecode.microbit.org)
 *   1. Use a micro:bit V2 (V1 usually runs out of memory with Bluetooth).
 *   2. Extensions -> add "bluetooth"; REMOVE "radio" (they cannot coexist).
 *      Add your own extensions (e.g. Cutebot) as needed for your control code.
 *   3. Project Settings (gear icon) -> Bluetooth Pairing -> "No Pairing Required".
 *      (Otherwise the laptop must pair with every micro:bit first.)
 *   4. Switch to JavaScript view, paste this file, download to the micro:bit.
 *
 * MESSAGE FORMAT
 *   Plain ASCII lines ending in newline, at most 19 characters + newline.
 *   Laptop -> micro:bit arrives in handleMessage(line).
 *   micro:bit -> laptop is sent with sendToLaptop("text").
 *
 * NOTE: nothing here stops motors if the link is lost. If your control code
 * drives motors, stop them in onBluetoothDisconnected below.
 */

// ---------------------------------------------------------------------------
// 1. SEND: one line to the laptop
//    The newline tells the laptop where the message ends. Keep text <= 19 chars.
// ---------------------------------------------------------------------------
function sendToLaptop(text: string) {
    bluetooth.uartWriteString(text + "\n")
}

// ---------------------------------------------------------------------------
// 2. HELPER: remove trailing newline / carriage return characters.
//    Depending on the firmware, uartReadUntil may or may not keep the delimiter,
//    so this makes the handler behave the same either way.
// ---------------------------------------------------------------------------
function stripEnd(s: string): string {
    while (s.length > 0 && (s.charAt(s.length - 1) == "\n" || s.charAt(s.length - 1) == "\r")) {
        s = s.substr(0, s.length - 1)
    }
    return s
}

// ---------------------------------------------------------------------------
// 3. YOUR CODE GOES HERE: called once for every complete line from the laptop.
//    The default below answers "P" with "PONG" so the link can be tested.
// ---------------------------------------------------------------------------
function handleMessage(line: string) {
    if (line == "P") {
        sendToLaptop("PONG")
    }
}

// ---------------------------------------------------------------------------
// 4. BLUETOOTH EVENTS
// ---------------------------------------------------------------------------
// Connected: show a tick so you can see which micro:bits the laptop reached.
bluetooth.onBluetoothConnected(function () {
    basic.showIcon(IconNames.Yes)
})

// Disconnected: show a cross. (Stop any motors here if your code drives them.)
bluetooth.onBluetoothDisconnected(function () {
    basic.showIcon(IconNames.No)
})

// Runs each time a complete line (ending in newline) has arrived.
bluetooth.onUartDataReceived(serial.delimiters(Delimiters.NewLine), function () {
    handleMessage(stripEnd(bluetooth.uartReadUntil(serial.delimiters(Delimiters.NewLine))))
})

// ---------------------------------------------------------------------------
// 5. STARTUP
// ---------------------------------------------------------------------------
bluetooth.startUartService()                    // exposes the Nordic UART service
basic.showIcon(IconNames.SmallDiamond)          // "waiting for connection"
